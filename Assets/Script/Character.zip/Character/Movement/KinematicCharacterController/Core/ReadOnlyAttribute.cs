﻿using UnityEngine;

namespace KinematicCharacterController
{
    public class ReadOnlyAttribute : PropertyAttribute
    {
    }
}